CREATE TRIGGER tri_insert
AFTER INSERT ON tb_event_article
FOR EACH ROW
  begin
	DECLARE e_num int;
	DECLARE e_date, s_dt, e_dt DATETIME ;
	set e_date = STR_TO_DATE(new.time,'%Y-%m-%d %H:%i:%s');
 	set s_dt = concat(DATE(e_date) , ' ', HOUR(new.time));
 	set e_dt = concat(DATE(e_date), ' ', HOUR( date_add(new.time, interval 1 hour)));

	SELECT COUNT(*) INTO e_num FROM tb_source_article_num WHERE table_id = new.table_id AND event_id = new.event_id and start_time = s_dt;
	IF e_num = 0 THEN
 		INSERT INTO tb_source_article_num(ID, table_id, event_id, num, start_time, end_time) VALUES (UUID(), new.table_id, new.event_id, 1, s_dt, e_dt);
	ELSE
		UPDATE tb_source_article_num SET num = num + 1 WHERE table_id = new.table_id AND event_id = new.event_id and start_time = s_dt;
	END IF;
end;
