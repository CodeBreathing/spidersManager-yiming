CREATE TRIGGER tri_delete
AFTER DELETE ON tb_event_article
FOR EACH ROW
  begin
	DECLARE e_date, s_dt DATETIME ;
	set e_date = STR_TO_DATE(old.time,'%Y-%m-%d %H:%i:%s');
 	set s_dt = concat(DATE(e_date) , ' ', HOUR(old.time));
	UPDATE tb_source_article_num SET num = num - 1 WHERE table_id = old.table_id AND event_id = old.event_id and start_time = s_dt;
end;
